public class Gasolina extends Motor{

    public Gasolina(int potencia) {
        super(potencia, "Gasolina");
    }
    
}
