public interface Impacto {
    float calcular_impacto();
}
