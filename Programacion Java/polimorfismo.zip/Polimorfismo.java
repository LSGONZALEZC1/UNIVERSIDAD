/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package polimorfismo;

/**
 *
 * @author salas
 */
public class Polimorfismo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Vehiculo[] parqueadero = new Vehiculo[3];
        parqueadero[0] = new Moto(125,2,2);
        parqueadero[1] = new deportivo(600, 2, 4, 4);
        parqueadero[2] = new Camion(1200, 2, 2, 16);
        
        for (Vehiculo vehiculo : parqueadero) {
            System.out.println("Los datos del vehículo son: ");
            System.out.println(vehiculo);
            System.out.println("====== w ========= w ======");
        }
    }
    
    
}
