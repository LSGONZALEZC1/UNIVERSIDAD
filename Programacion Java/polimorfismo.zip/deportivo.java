/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polimorfismo;

/**
 *
 * @author salas
 */
public class deportivo extends Auto {
    protected int potencia;

    public deportivo(int potencia, int puertas, int pasajeros, int ruedas) {
        super(puertas, pasajeros, ruedas);
        this.potencia = potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    public int getPotencia() {
        return potencia;
    }

    @Override
    public String toString() {
        return super.toString()+ "deportivo [ potencia =" + this.potencia + " ]"; 
    }
    
    
}
