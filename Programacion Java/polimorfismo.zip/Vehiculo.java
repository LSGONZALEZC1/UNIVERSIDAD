/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polimorfismo;

/**
 *
 * @author salas
 */
public class Vehiculo {

    protected int pasajeros;
    protected int ruedas;

    public Vehiculo() {
        this.pasajeros = 0;
        this.ruedas = 0;
    }

    public Vehiculo(int pasajeros, int ruedas) {
        this.pasajeros = pasajeros;
        this.ruedas = ruedas;
    }

    public int getPasajeros() {
        return pasajeros;
    }

    public void setPasajeros(int pasajeros) {
        if (pasajeros > 0) {
            this.pasajeros = pasajeros;
        }else{
            System.err.println("Pana, sea serio use positivos");
            this.pasajeros=0;
        }
        
    }

    public int getRuedas() {
        return ruedas;
    }

    public void setRuedas(int ruedas) {
        if (ruedas<0){
         System.err.println("Pana, sea serio use positivos");
         this.ruedas=0;
        }
        else{this.ruedas = ruedas;}
    }

    @Override
    public String toString() {
        return "Vehículo [ruedas: "+ this.ruedas + " ,Pasajeros " + this.pasajeros+ " ]";
                }

    
}
