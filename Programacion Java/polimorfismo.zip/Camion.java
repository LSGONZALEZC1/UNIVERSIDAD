/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polimorfismo;

/**
 *
 * @author salas
 */
public class Camion extends Auto {
    protected int capacidad;

    public Camion(int capacidad, int puertas, int pasajeros, int ruedas) {
        super(puertas, pasajeros, ruedas);
        this.capacidad = capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public int getCapacidad() {
        return capacidad;
    }

    @Override
    public String toString() {
        return super.toString()+ "camión [capacidad ="+ this.capacidad +" ]"; 
    }
    
    
}
