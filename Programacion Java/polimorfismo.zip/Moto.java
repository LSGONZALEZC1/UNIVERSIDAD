/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polimorfismo;

/**
 *
 * @author salas
 */
public class Moto extends Vehiculo{
    protected int cilidraje;

    

    public Moto(int cilidraje, int pasajeros, int ruedas) {
        super(pasajeros,2);
        if (ruedas<=2){
        this.ruedas=ruedas;
        this.cilidraje = cilidraje;
        }
    }



    public int getCilidraje() {
        return cilidraje;
    }

    public void setCilidraje(int cilidraje) {
        this.cilidraje = cilidraje;
    }

    @Override
    public String toString() {
        return super.toString()+ "\n Moto [cilindraje:" + this.cilidraje +" ]"; 
    }

  
    
    
}
