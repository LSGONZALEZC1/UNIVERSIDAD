/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polimorfismo;

/**
 *
 * @author salas
 */
public class Auto extends Vehiculo {

    protected int puertas;

    public Auto(int puertas, int pasajeros, int ruedas) {
        super(pasajeros, ruedas);
        this.puertas = puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public int getPuertas() {
        return puertas;
    }

    @Override
    public String toString() {
        return super.toString()+ "Auto[" + "puertas=" + puertas + ']';
    }

}
