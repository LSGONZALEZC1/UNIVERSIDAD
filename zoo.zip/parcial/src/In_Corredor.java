public interface In_Corredor{
 
    public String Corredor();
}