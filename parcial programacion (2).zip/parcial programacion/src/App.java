public class App {

    public static void main(String[] args){

        System.out.println("\nCatalogo de Animales del ZOO\n");

        Obj_Avestruz a1=new Obj_Avestruz(null, null, null, null, 0, 0);
        a1.setNombre("Avestrus");
        a1.setGenero("Struthio");
        a1.setEspecie("camelus");
        a1.setPeso(120);
        a1.setProcedencia("Tanzania");
        a1.setEnvergadura_alas(2.0);

        System.out.println("\nNombre: "+a1.getNombre()+"\nGenero: "+a1.getGenero()+"\nEspecie: "+a1.getEspecie()+"\nPeso: "+a1.getPeso()+"\nProcedencia: "+a1.getProcedencia()+"\nEnvergadura: "+a1.getEnvergadura_alas());

        Obj_Puma p1=new Obj_Puma(null, null, null, null, 0, 0);
        p1.setNombre("Puma");
        p1.setGenero("Puma");
        p1.setEspecie("concolos");
        p1.setPeso(80);
        p1.setProcedencia("perú");
        p1.setTiempo_de_encubacion(90);

        System.out.println("\nNombre: "+p1.getNombre()+"\nGenero: "+p1.getGenero()+"\nEspecie: "+p1.getEspecie()+"\nPeso: "+p1.getPeso()+"\nProcedencia: "+p1.getProcedencia()+"\nPeriodo de incubacion:: "+p1.getTiempo_de_encubacion());

        Obj_Halcon h1=new Obj_Halcon(null, null, null, null, 0, 0);
        h1.setNombre("halcon moteado");
        h1.setGenero("falco");
        h1.setEspecie("punctatus");
        h1.setPeso(0.25);
        h1.setProcedencia("isla Mauricio");
        h1.setEnvergadura_alas(0.52);

        System.out.println("\nNombre: "+h1.getNombre()+"\nGenero: "+h1.getGenero()+"\nEspecie: "+h1.getEspecie()+"\nPeso: "+h1.getPeso()+"\nProcedencia: "+h1.getProcedencia()+"\nEnvergadura: "+h1.getEnvergadura_alas());

        Obj_Titi t1=new Obj_Titi(null, null, null, null, 0, 0);
        t1.setNombre("titi del chaco");
        t1.setGenero("callicebus");
        t1.setEspecie("pallecens");
        t1.setPeso(0.400);
        t1.setProcedencia("paraguay");
        t1.setTiempo_de_encubacion(183);

        System.out.println("\nNombre: "+t1.getNombre()+"\nGenero: "+t1.getGenero()+"\nEspecie: "+t1.getEspecie()+"\nPeso: "+t1.getPeso()+"\nProcedencia: "+t1.getProcedencia()+"\nEnvergadura: "+t1.getTiempo_de_encubacion());

        Obj_Condor c1=new Obj_Condor(null, null, null, null, 0, 0);
        c1.setNombre("condor");
        c1.setGenero("vultur");
        c1.setEspecie("gryphus");
        c1.setPeso(14);
        c1.setProcedencia("chile");
        c1.setEnvergadura_alas(2.83);

        System.out.println("\nNombre: "+h1.getNombre()+"\nGenero: "+h1.getGenero()+"\nEspecie: "+h1.getEspecie()+"\nPeso: "+h1.getPeso()+"\nProcedencia: "+h1.getProcedencia()+"\nEnvergadura: "+h1.getEnvergadura_alas());


    }
    
}