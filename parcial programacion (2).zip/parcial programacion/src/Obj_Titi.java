public class Obj_Titi extends Cla_Mamifero{

    public Obj_Titi(String nombre, String genero, String especie, String procedencia, double peso, int tiempo_de_incubacion) {
        super(nombre, genero, especie, procedencia, peso, tiempo_de_incubacion);
    }
    
}