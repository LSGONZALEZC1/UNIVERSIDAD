function condcodige(){
    y=0+1;
    x=document.getElementById("nomest").value;
    document.getElementById("condcodige").innerHTML =
     "codige:" + x+ "se ha guardado";
}