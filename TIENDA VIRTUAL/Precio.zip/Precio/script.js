function confprecio() {

    y=0+1;
    x = document.getElementById("pres").value;
    document.getElementById("confprecio").innerHTML =
      "El precio del producto # " + y +": "+ x +" a sido añadido ";
      
  }
  