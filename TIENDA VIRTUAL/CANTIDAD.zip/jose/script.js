function mostrarNumeroArticulos() {
  x = document.getElementById("ingresoNumeroArticulos").value;
  document.getElementById("mostrarNumeroArticulos").innerHTML =
    "Cantidad de artículos disponibles: " + x;
}
