function confdiescripcion() {
    y=0+1;
    x = document.getElementById("nomest").value;
    document.getElementById("confdiescripcion").innerHTML =
      "descriopcion: "+y+" "+ x+" se a guardado ";
  }
  