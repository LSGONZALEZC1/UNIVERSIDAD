//Librerias
#include <iostream>
#include <cctype>
//L. para limpiar pantalla
#ifdef _WIN32
#include<windows.h>
#endif

/*
NOMBRE DE LA LIB. UTILIZADA ---> Librería ctype ANSI 

Contiene los prototipos de las funciones y macros de clasificación de caracteres.
*/
using namespace std;

/*boleano y nombre de la funcion ()*/
bool verificacion(string c){

  bool longitud=false;
  bool mayuscula=false;
  bool minuscula=false;       
  bool numero__carc_espec=false;

  const string RED("\033[31m");
  const string GREEN("\033[32m");  

  if (c.length()>=8 && c.length()<=16){
    longitud=true;
  }
    
/*
condicional que mide el largo de la cadena y se utilizo el metodo length que devuelve el largo de la cadena
*/

  for(int i=0; i<c.length(); i++){

    if (isupper(c[i])){
      mayuscula=true; 
    }

    if (islower(c[i])){
      minuscula=true;
    }

    if (isdigit(c[i])){
      numero__carc_espec=true;
    }

  }

  if(longitud){
    cout<<GREEN<<"\n- Cumple con el rango de longitud de 8-16";
  }
  else{
    cout<<RED<<"\n- No cumple con el rango de longitud de 8-16";
  }

  if(mayuscula){
    cout<<GREEN<<"\n- Contiene al menos una letra mayuscula";
  }
  else{
    cout<<RED<<"\n- No contiene letras mayusculas";
  }

  if(minuscula){
    cout<<GREEN<<"\n- Contiene al menos una letra minuscula";
  }
  else{
    cout<<RED<<"\n- No contiene letras minusculas";
  }

  if(numero__carc_espec){
    cout<<GREEN<<"\n- Contiene al menos un numero y/o  un caracter especial";
  }
  else{
    cout<<RED<<"\n- No contiene numeros ni caracteres especiales";
  }

    if (longitud && mayuscula && minuscula && numero__carc_espec){
    return true;
  }

  else{
    return false;
  }

}//Fin Verificaciones

int main() {

  string password;
  bool verif;
  int respuesta;

  const string RESET("\033[0m");

  do{

  cout<<"\n--Verificacion de Contraseña--\n";

  cout<<"\n¿Desea saber si una contraseña es segura?"
      <<"\nDigite 1 para si y 2 para no\n";
  cout<<"\n° "; cin>>respuesta;

  void lim_pant();
	{
    #ifdef _WIN32
      system("cls");
    #else
		  system("clear");
    #endif
	}//Limpiar pantalla

    switch(respuesta){
      case 1:
        cout<<RESET<<"\nIngrese su contraseña para ser verificada\n";
        cout<<"\n° "; cin>>password;
        
        verif=verificacion(password);
        
        if (verif){
          cout<<RESET<<"\n\n**La contraseña es segura**\n\n\n";
        }
        
        else{
          cout<<RESET<<"\n\nLa contraseña no es muy seggura."
              <<"\nNo cumplio con las anteriores caracteristicas\n\n";
        }

      break;

      case 2:

      break;
    }
    
  }while(respuesta != 2);

} 