#include <iostream>
#include <random>

using namespace std;

int main(int argc, char* argv[]) {
  
  int longi;
  string cont;
  
  cout<<"\n--Contraseña Aleatoria--\n";
  
  if(argc <= 1){
   
    cout<<"\nIngrese cantos caracteres tendra la contraseña: "; 
    cin>>longi;
  } 
  
  else{
    
    longi=atoi(argv[1]);
  }

  random_device rd;//generador de numeros aleatorios
  default_random_engine rng(rd());
  uniform_int_distribution<char> ascii(32,126);
  
  for(int i=0; i<longi; i++){
    
    char caracter = ascii(rng);
    cont += caracter;
    
  }
  
  cout<<"\nSu contraseña es: "<<cont<<"\n";

}