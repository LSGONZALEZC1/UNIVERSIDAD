/*
Laura Sofia Gonzalez Castaño 30000091406
lsgonzalec1@correo.usbcali.edu.con

Leydi Vanesa Guiral Palechor 30000091872
lvguiralp@correo.usbcali.edu.con

*/

//Librerias
#include <iostream>
#include <fstream>
//L. para limpiar pantalla
#ifdef _WIN32
#include<windows.h>
#endif
using namespace std;

bool es_Primo (int n){

  ofstream output;
  output.open("input.txt");

  bool primo=false;

  const string RED("\033[31m");
  const string GREEN("\033[32m");  

    for (int num=1; num<=n; num++){
   // output<<num<<endl;

    if (num/num==1 && num/1==num){
      primo=true;
      output<<num<<endl;
      cout<<GREEN<<"\n° "<<num<<"   TRUE";
      
    }

    else{
      return false;
      output<<num;
      cout<<RED<<"\n° "<<num<<"   FALSE" ;
      
    }
      
  }

  if (primo){
    return true;
  }
  else{
    return false;
  }
  
}

int main() {

  int numero;
  bool verif;
  const string RESET("\033[0m");

  cout<<"\n---Buscador de Primos---\n";

  cout<<"\nIngrese un numero: ";
  cin>>numero;

  verif=es_Primo(numero);

  if (verif){
    cout<<RESET<<"\n\nRevisa el arcivo :) :(";
  }

}