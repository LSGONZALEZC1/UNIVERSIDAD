public class Bicicleta implements impacto_ecologico {

    int Kilometraje_recorrido;

    public Bicicleta(int kilometraje_recorrido) {
        Kilometraje_recorrido = kilometraje_recorrido;
    }

    public int getKilometraje_recorrido() {
        return Kilometraje_recorrido;
    }

    public void setKilometraje_recorrido(int kilometraje_recorrido) {
        Kilometraje_recorrido = kilometraje_recorrido;
    }  
    
    @Override
    public float Calcular_impacto(double impacto) {
        impacto=0.0069*Kilometraje_recorrido;
        System.out.println("\nEl impacto ecologico producido este año fue de "+impacto+" toneladas de CO2");
        return Kilometraje_recorrido;
    }

}
