public class Auto implements impacto_ecologico {

int kilometraje_recorrido;
String motor;
double coeficiente;

public Auto(int kilometraje_recorrido, String motor) {
    this.kilometraje_recorrido = kilometraje_recorrido;
    this.motor = motor;
}


public int getKilometraje_recorrido() {
    return kilometraje_recorrido;
}



public void setKilometraje_recorrido(int kilometraje_recorrido) {
    this.kilometraje_recorrido = kilometraje_recorrido;
}



public String getMotor() {
    return motor;
}



public void setMotor(String motor) {

    if (motor=="diesel"){
        coeficiente=0.730;
    }
    else if (motor=="gasolina"){
        coeficiente=0.329;
    }
    else if (motor=="electrico"){
        coeficiente=0.02;
    }

    this.motor = motor;
}


@Override
public float Calcular_impacto(double impacto) {
    impacto=coeficiente*kilometraje_recorrido;
    System.out.println("\nEl impacto ecologico producido este año fue de "+impacto+" toneladas de CO2");
    return kilometraje_recorrido;
}

}
