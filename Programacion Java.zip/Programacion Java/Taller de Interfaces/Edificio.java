public class Edificio implements impacto_ecologico {

    int Area; 
    int Ascensores;
    int Generadores_diesel;
 
    public Edificio(int area, int ascensores, int generadores_diesel) {
        Area = area;
        Ascensores = ascensores;
        Generadores_diesel = generadores_diesel;
    }

    public int getArea() {
        return Area;
    }

    public void setArea(int area) {
        Area = area;
    }

    public int getAscensores() {
        return Ascensores;
    }

    public void setAscensores(int ascensores) {
        Ascensores = ascensores;
    }

    public int getGeneradores_diesel() {
        return Generadores_diesel;
    }

    public void setGeneradores_diesel(int generadores_diesel) {
        Generadores_diesel = generadores_diesel;
    }

    @Override
    public float Calcular_impacto(double impacto) {
        impacto=Area*(0.853)+Ascensores*(0.472)+Generadores_diesel*(0.914);
        System.out.println("\nEl impacto ecologico producido este año fue de "+impacto+" toneladas de CO2");
        return Area;
    }



}