public class Electrico extends Motor {

    public Electrico(int potencia) {
        super(potencia, "Eléctrico");
    }
    
}
