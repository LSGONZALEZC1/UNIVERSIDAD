public class Especializacion extends fechaGrado {

    protected String pregrado_base;

    public String getPregrado_base() {
        return pregrado_base;
    }

    public void setPregrado_base(String pregrado_base) {
        this.pregrado_base = pregrado_base;
    }

    @Override
    public String toString(){
        return "";
    }

    public void setCodigo(String string) {
    }
    
}
