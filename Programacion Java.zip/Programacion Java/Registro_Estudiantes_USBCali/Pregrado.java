public class Pregrado extends Estudiante {

    protected int creditos_aprobados;
    protected float promedio_acumulado;

    public int getCreditos_aprobados() {
        return creditos_aprobados;
    }
    public void setCreditos_aprobados(int creditos_aprobados) {
        this.creditos_aprobados = creditos_aprobados;
    }
    public float getPromedio_acumulado() {
        return promedio_acumulado;
    }
    public void setPromedio_acumulado(float promedio_acumulado) {
        this.promedio_acumulado = promedio_acumulado;
    }

    @Override
    public String toString(){
        return "";
    }
    public void setPromedio_acumulado(String string) {
    }
    public void setCreditos_aprobados(String string) {
    }
    public void setCodigo(String string) {
    }
    
}
