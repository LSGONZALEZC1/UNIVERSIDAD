public class Pago_efectivo extends Pago{
    public Pago_efectivo(String cliente, int monto, String fecha) {
        super(cliente, monto, fecha);
    
    }
  
}